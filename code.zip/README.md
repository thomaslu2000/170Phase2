# project-fa19
CS 170 Fall 2019 Project

To run our solver, run the following instructions on the command line:

python solver.py --all inputs

This instruction will run our solver on all of the inputs in the inputs folder and produce outputs of corresponding names. 